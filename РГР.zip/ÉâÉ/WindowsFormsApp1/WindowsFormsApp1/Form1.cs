﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace InfectionSimulation
{
    public partial class Form1 : Form
    {
        private const int n = 15;
        private const int initialInfectionDuration = 6;
        private const int immunityDuration = 4;

        private CellState[,] grid;
        private Random random;

        public Form1()
        {
            InitializeComponent();
            InitializeGrid();
        }

        private void InitializeGrid()
        {
            grid = new CellState[n, n];
            random = new Random();

            int center = n / 2;
            grid[center, center] = CellState.Infected;
            DisplayGrid();
        }

        private void DisplayGrid()
        {
            panelGrid.Controls.Clear();

            int cellSize = 30;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Label label = new Label();
                    label.Size = new Size(cellSize, cellSize);
                    label.TextAlign = ContentAlignment.MiddleCenter;
                    label.BorderStyle = BorderStyle.FixedSingle;

                    switch (grid[i, j])
                    {
                        case CellState.Healthy:
                            label.BackColor = Color.LightGreen;
                            label.Text = "H";
                            break;
                        case CellState.Infected:
                            label.BackColor = Color.OrangeRed;
                            label.Text = "I";
                            break;
                        case CellState.Immune:
                            label.BackColor = Color.LightBlue;
                            label.Text = "IM";
                            break;
                    }

                    panelGrid.Controls.Add(label);
                    label.Location = new Point(j * cellSize, i * cellSize);
                }
            }
        }

        private void SimulateInfection()
        {
            for (int time = 1; time <= initialInfectionDuration + immunityDuration; time++)
            {
                CellState[,] nextGrid = new CellState[n, n];

                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        switch (grid[i, j])
                        {
                            case CellState.Healthy:
                                nextGrid[i, j] = CheckInfection(i, j) ? CellState.Infected : CellState.Healthy;
                                break;
                            case CellState.Infected:
                                nextGrid[i, j] = CellState.Immune;
                                break;
                            case CellState.Immune:
                                nextGrid[i, j] = CellState.Healthy;
                                break;
                        }
                    }
                }

                grid = nextGrid;
                DisplayGrid();
                System.Threading.Thread.Sleep(500);
            }
        }

        private bool CheckInfection(int x, int y)
        {
            if (grid[x, y] == CellState.Healthy)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        if (dx != 0 || dy != 0)
                        {
                            int nx = x + dx;
                            int ny = y + dy;
                            if (nx >= 0 && nx < n && ny >= 0 && ny < n)
                            {
                                if (grid[nx, ny] == CellState.Infected && random.NextDouble() < 0.5)
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            SimulateInfection();
        }
    }

    public enum CellState
    {
        Healthy,
        Infected,
        Immune
    }
}
